ICAART 2027 paper 219 - LaTeX source package

Main manuscript: main.tex (the only .tex file in this archive).
Includes the bibliography, local class/style files, and both PDF figures.

Build from this directory with a standard TeX Live or MiKTeX installation:

pdflatex -interaction=nonstopmode -halt-on-error main.tex
bibtex main
pdflatex -interaction=nonstopmode -halt-on-error main.tex
pdflatex -interaction=nonstopmode -halt-on-error main.tex
pdflatex -interaction=nonstopmode -halt-on-error main.tex

The figures directory must remain alongside main.tex.
No repository files are needed. The manuscript is eight pages.
