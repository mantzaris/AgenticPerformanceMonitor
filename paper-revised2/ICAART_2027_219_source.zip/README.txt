ICAART 2027 paper 219 - LaTeX source package

Main manuscript: main.tex
This is the eight-page second revision, including author affiliations and the
one-sentence AI Assistance Disclosure.

Included: all three LaTeX source files from paper-revised2, bibliography source,
compiled bibliographies, local class/style files, and both PDF figures.
changes.tex and changes-from-first.tex are optional marked-up comparisons;
main.tex is the manuscript to use for publication.

Build from this directory with a standard TeX Live or MiKTeX installation:

pdflatex -interaction=nonstopmode -halt-on-error main.tex
bibtex main
pdflatex -interaction=nonstopmode -halt-on-error main.tex
pdflatex -interaction=nonstopmode -halt-on-error main.tex
pdflatex -interaction=nonstopmode -halt-on-error main.tex

To build a comparison, replace main with changes or changes-from-first in
these commands. No repository files or latexdiff installation are needed.
The figures directory must remain alongside the LaTeX files.
